# CS 405 Coding Files

This folder collects the coding work used throughout CS 405 Secure Coding.

## Included exercises

- **Numeric Overflow** — checks arithmetic before an overflow or underflow happens.
- **Buffer Overflow** — limits user input before it can exceed the original buffer size.
- **Exceptions** — handles divide-by-zero, standard exceptions, and a custom exception.
- **SQL Injection** — blocks the tautology-style injection patterns used by the course exercise. In a real application, prepared statements should be preferred for user-supplied values.
- **Encryption** — reads a file, applies repeating-key XOR for the course exercise, and writes encrypted/decrypted output files.
- **Static Code Analysis** — contains the intentionally questionable source used with Visual Studio Code Analysis and Cppcheck, plus the redacted Cppcheck XML output.
- **Unit Testing** — completed GoogleTest collection tests plus the bounds tests used in Project Two.
- **Exploit Examples** — the small Python exploit/non-exploit examples used during the course.

Some source files were reconstructed from the original course starter files and their TODO requirements because only the starter copies were still available in the portfolio workspace.
